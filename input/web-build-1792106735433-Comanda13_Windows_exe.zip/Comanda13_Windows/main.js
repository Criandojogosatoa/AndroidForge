const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
function create() {
  Menu.setApplicationMenu(null);
  const w = new BrowserWindow({
    width: 1280, height: 720, backgroundColor: '#000000', autoHideMenuBar: true,
    title: 'Comanda 13: O Último Pedido',
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false }
  });
  w.loadFile(path.join(__dirname, 'index.html'));
  w.webContents.on('before-input-event', (e, i) => {
    if (i.type !== 'keyDown') return;
    if (i.key === 'F11') { w.setFullScreen(!w.isFullScreen()); e.preventDefault(); }
    if (i.key === 'F12' || (i.control && i.shift && i.key.toLowerCase() === 'i')) { w.webContents.toggleDevTools(); e.preventDefault(); }
  });
}
app.whenReady().then(create);
app.on('window-all-closed', () => app.quit());
